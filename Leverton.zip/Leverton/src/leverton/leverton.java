package leverton;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class leverton {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		//Setting the path of chromedriver.
		System.setProperty("webdriver.chrome.driver", "/Users/sajupt/Desktop/chromedriver");
		WebDriver driver = new ChromeDriver();
		driver.get("https://viewer-dev.lvn.com");
		
		
		WebDriverWait wait = new WebDriverWait(driver, 15);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("username")));
		
		//Passing the username and password
		driver.findElement(By.id("username")).sendKeys("Test");
		driver.findElement(By.id("password-field")).sendKeys("Test");
		driver.findElement(By.className("btn")).click();
		
		//Checking if an error message is displayed.
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        String expText = "Sorry, we were not able to find a user with that username and password.";
        
        String pageSource = driver.getPageSource();
        if(pageSource.contains(expText)){
            System.out.println("Expected text '"+expText+"' present in the web page.");
        }else{
            System.out.println("Expected text '"+expText+"' is not present in the web page.");
        }
		
        
        //Changing the language to German
        driver.findElement(By.xpath("//*[@id=\"user-info\"]/div/div/a[1]")).click();
        String currentURL = null;
		currentURL = driver.getCurrentUrl();
        System.out.println(currentURL);
        
String expectedURL = "https://viewer-dev.leverton.ai/login/auth?login_error=1&lang=de";
       
        
        //Comparing the current and expected Url.
        if(currentURL.equals(expectedURL))
    	    System.out.println("Language changed to German");
        else
    	    System.out.println("Language not changed to German");
  
       Thread.sleep(5000);
        
        
        //Changing the language to Spanish
        driver.findElement(By.xpath("//*[@id=\"user-info\"]/div/div/a[3]")).click();
  
        String currentURL1 = null;
		currentURL1 = driver.getCurrentUrl();
        System.out.println(currentURL1);
        
        
        
        
String expectedURL1 = "https://viewer-dev.leverton.ai/login/auth?login_error=1&lang=es";
       
        
        //Comparing the current and expected Url.
        if(currentURL1.equals(expectedURL1))
    	    System.out.println("Language changed to Spanish");
        else
    	    System.out.println("Language not changed to Spanish");
		
	}

}
